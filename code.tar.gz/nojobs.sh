./start 5
sleep 1
./consumer 1
